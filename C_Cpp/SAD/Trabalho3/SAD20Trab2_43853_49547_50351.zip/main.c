/*
 * File:   main.c
 * Author: Rafael
 *
 * Created on 14 de Maio de 2020, 14:04
 */

#include <xc.h>
#include <htc.h>

#include <stdio.h>
#include <string.h>

#pragma config FOSC = HS // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF // Watchdog Timer Enable bit
#pragma config PWRTE = OFF // Power-up Timer Enable bit
#pragma config BOREN = OFF // Brown-out Reset Enable bit
#pragma config LVP = OFF // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit
#pragma config CPD = OFF // Data EEPROM Memory Code Protection bit
#pragma config WRT = OFF // Flash Program Memory Write Enable bits
#pragma config CP = OFF // Flash Program Memory Code Protection bit

#define SDA      RC4        // Data pin for i2c
#define SCK      RC3        // Clock pin for i2c
#define SDA_DIR    TRISC4      // Data pin direction
#define SCK_DIR    TRISC3      // Clock pin direction
#define I2C_SPEED  100        // kbps

#define EEPROM_Address_R 0xA1
#define EEPROM_Address_W 0xA0

#define TEMP 0x02
#define HUM 0x01
#define WIND 0x00
#define PASS "2020\0"

char string[20];
char received;
int stop;
int pass;
int countt0=0;
int sec=0;
int minuto=0;
int t, h, v=0; //armazenar os valores lidos pelo ADC
int limt, limh, limv, rajada; //limites para ocorr�ncia de situa��o de risco

void delay(int d){
	int i = 0;
	int j = 0;
	for (i = 0; i<d ; i++){ 
		for (j = 0; j < 300 ; j ++){}
	}
}

void inttoStr(int x, char *string){

	sprintf(string, "%d", x);
}

/*********************************************************Fun��es USART**************************************************/
void initUSART(){
     SPBRG=25; // Baud Rate para 4 MHz
     TXSTAbits.BRGH=1; //High Speed Communication
     
     TXSTAbits.SYNC=0; //Asynchronous data transfer
     RCSTAbits.SPEN=1; //Serial Port enabled
     
     TXSTAbits.TXEN=1; //Transmit Enabled, also sets bit TXIF
     RCSTAbits.CREN=1; //Enables Continuous receive in Asynchronous mode       
}

void transmitChar(char c){

		while(!TXIF);
		TXREG=c;
}	

void transmitString(char s[]){
    
	int i=0;
		
	while(s[i]!='\0') transmitChar(s[i++]);						
}
	
char receiveChar(){
    
    if(OERR){ // check for error
        CREN=0;
        CREN=1;
    }
		
	while(!RCIF){};
    return RCREG;
}
	
/*char *receiveString(char *s){
		

	char ch;
	do{
        ch = receiveChar();
        *s = ch;
        s++;
    }while(ch!='\r' && ch!='\n');
	s--;
	*s = '\0';
    return s;
	//while((ch=receiveChar())!='\0')	
}*/
/************************************************************************************************************************/

/*********************************************************Fun��es ADC****************************************************/
void ADC_init(){
    ADCON1=0xc9;  //11001001
    ADCON0=0x01;  //ADON=1: A/D powered up 
}

int ADC_read(int ch){
    
    unsigned int i;
    ADCON0bits.CHS = ch;
    ADCON0bits.GO_nDONE = 1;
    delay(10);
    while(ADCON0bits.GO_nDONE == 1){}
    i = ((ADRESH<<8) | (ADRESL & 0xff)); // Shift left ADRESH. 
    return i;
}

/************************************************************************************************************************/


/*********************************************************Fun��es PASS***************************************************/

char keyboardInput(){
    //TECLADO MATRICIAL
      
    PORTB=0xFF;
    TRISB=0; //PORTB a output
    PORTD=0xFF;
    TRISD=0xFF;//PORTD a input

    while(1){
        PORTBbits.RB1=0; //Habilita coluna 1
        if (!PORTDbits.RD3) {delay(25); return '1';}
        else if (!PORTDbits.RD2) {delay(25); return '4';}
        else if (!PORTDbits.RD1) {delay(25); return '7';}
        else if (!PORTDbits.RD0) {delay(25); return '*';}
        delay(10);
        PORTBbits.RB1=1; //DESHabilita coluna 1   

        PORTBbits.RB2=0; //Habilita coluna 2
        if (!PORTDbits.RD3) {delay(25); return '2';}
        else if (!PORTDbits.RD2) {delay(25); return '5';}
        else if (!PORTDbits.RD1) {delay(25); return '8';}
        else if (!PORTDbits.RD0) {delay(25); return '0';}
        delay(10);
        PORTBbits.RB2=1; //DESHabilita coluna 2 

        PORTBbits.RB0=0; //Habilita coluna 3
        if (!PORTDbits.RD3) {delay(25); return '3';}
        else if (!PORTDbits.RD2) {delay(25); return '6';}
        else if (!PORTDbits.RD1) {delay(25); return '9';}
        else if (!PORTDbits.RD0) {delay(25); return '#';}
        delay(10);
        PORTBbits.RB0=1; //DESHabilita coluna 3
    }
}

unsigned char code7s(char v)
{
  switch(v)
  {
    case '0':
      return 0x3F;
    case '1':
      return 0x06;
    case '2':
      return 0x5B;
    case '3':
      return 0x4F;
    case '4':
      return 0x66;
    case '5':
      return 0x6D;
    case '6':
      return 0x7D;
    case '7':
      return 0x07;
    case '8':
      return 0x7F;
    case '9':
      return 0x6F;
    default:
      return 0;
  }
}

void display7s (char code, char j){
    char tmpad, tmpporta, tmptrisa, tmpportd, tmptrisd;
    tmpad=ADCON1;
    tmpporta=PORTA;
    tmptrisa=TRISA;
    tmpportd=PORTD;
    tmptrisd=TRISD;
    
    ADCON1 =0x06; //configura todos os pinos AD como I/O digital
    PORTA = 0; //resseta todos os pinos do porta
    TRISA = 0; //define porta como saida
    TRISD = 0; //define portd como saida
    PORTD = 255; //seta todos os pinos do portd
   
    
    delay(30);
    switch(j)
      {
         case 3: 
           PORTA=0x20;
           break;
         case 2: 
           PORTA=0x10;
           break;
         case 1: 
           PORTA=0x08;
           break;
         case 0: 
           PORTA=0x04;
           break;
       }
    PORTD=code7s(code);
    delay(70);
    
    PORTA=tmpporta;
    TRISA=tmptrisa;
    PORTD=tmpportd;
    TRISD=tmptrisd;
    ADCON1=tmpad;
}

int password(){
    
    char code[5]="----\0";
    char i = 0; 
    char erase;
    char tmpporta, tmptrisa,tmpportb, tmptrisb, tmpportd, tmptrisd;
    tmpporta=PORTA;
    tmptrisa=TRISA;
    tmpportb=PORTB;
    tmptrisb=TRISB;
    tmpportd=PORTD;
    tmptrisd=TRISD;
    
    PORTA=0;
    TRISA=0;
    
    transmitString("Introduza a password e confirme com a tecla #\r\n");
    for(i=0;i<4;i++){
            code[i]= keyboardInput();
            if (code[i]=='*')return 0; 
            if (code[i]=='#'){i-=1; continue;}
            display7s(code[i],i);  
        }
    while(keyboardInput()!='#');
    if(!strcmp(code,PASS)){
        transmitString("Password correta. Bem vindo\r\n\n");
        for(i=0;i<4;i++){
        PORTA=0x3C;
        PORTD=0xFF;
        delay(10);
        PORTA=0;
        PORTD=0;
        delay(20);
        }
        PORTA=tmpporta;
        TRISA=tmptrisa;
        PORTB=tmpportb;
        TRISB=tmptrisb;
        PORTD=tmpportd;
        TRISD=tmptrisd;
        pass=1;
        return pass;    
    }
    else{
        transmitString("Password incorreta! Tente outra vez.\r\n\n");
        PORTA=tmpporta;
        TRISA=tmptrisa;
        PORTB=tmpportb;
        TRISB=tmptrisb;
        PORTD=tmpportd;
        TRISD=tmptrisd;
        pass=0;
        return pass;

    }   
}

/************************************************************************************************************************/

/*********************************************************I2C************************************************************/
/*
void Init_I2C(){ //Setup I2C in Master Mode
    
    SDA_DIR = 1; //input
    SCK_DIR = 1; //input
    SSPADD = 4;  //When SSP configured in Master mode, lower seven bits act as the baud rate generator reload value.
    SSPSTAT = 0x80; //Slew Rate control is disabled
    SSPCON = 0x28; //select and enable I2C in master mode
    SSPCON2 = 0x00;
}

void I2C_wait(){ //Garantir que o estado anterior foi concluido
    while ((SSPSTAT & 0x04) || (SSPCON2 & 0x1F));
}

void I2C_start(){ //Start Condition
    I2C_wait();
    SEN = 1; //send start bit
    
}

void I2C_stop(){ //Stop Condition
    I2C_wait();
    PEN = 1; //send stop bit
    
}

void I2C_restart(){ //Restart Condition
    I2C_wait();
    RSEN = 1; //send start bit
   
}

void I2C_ACK(){ 
    I2C_wait();
    ACKDT = 0; // 0-> ACK, 1->NACK
    ACKEN = 1; // Envia o sinal
   
}

void I2C_NACK(){
    I2C_wait();
    ACKDT = 1; // 0-> ACK, 1->NACK
    ACKEN = 1; // Envia o sinal
}

char I2C_sendByte(unsigned char byte){
    I2C_wait();
    SSPBUF = byte;
}

char I2C_readByte(){
    int temp;
    I2C_wait();
    RCEN = 1;
    I2C_wait();
    temp=SSPBUF;
    I2C_wait();
    SSPIF = 0;
    return SSPBUF;
}

void EEPROM_writeByte(unsigned int x, unsigned char byte){
    I2C_start();
    
    while (I2C_sendByte(EEPROM_Address_W)) 
        I2C_restart();
    
    I2C_sendByte(x>>8);
    I2C_sendByte((unsigned char)x);
    I2C_sendByte(byte);
    I2C_stop();
    
}

void EEPROM_writeString(unsigned int x, char *byte, unsigned int len){
    I2C_start();
    
    while (I2C_sendByte(EEPROM_Address_W)) 
        I2C_restart();
    
    I2C_sendByte(x>>8);
    I2C_sendByte((unsigned char)x);
    for (int i = 0; i < len; i++) 
        I2C_sendByte(byte[i]);
    I2C_stop();
}

unsigned char EEPROM_readByte(unsigned int x){
  unsigned char byte;
  I2C_start();
 
  // Wait Until EEPROM Is IDLE
  while(I2C_sendByte(EEPROM_Address_W))
    I2C_restart();
 
  I2C_sendByte(x>>8);
  I2C_sendByte((unsigned char)x);
  I2C_restart();
 
  I2C_sendByte(EEPROM_Address_R);
  byte = I2C_readByte();
  I2C_NACK();
  I2C_stop();
 
  return byte;
    
}

void EEPROM_readString(unsigned int x, char *byte, unsigned int len){
    I2C_start();
 
  // Wait Until EEPROM Is IDLE
  while(I2C_sendByte(EEPROM_Address_W))
    I2C_restart();
 
  I2C_sendByte(x>>8);
  I2C_sendByte((unsigned char)x);
  I2C_restart();
  I2C_sendByte(EEPROM_Address_R);
  for(unsigned int i=0; i<len; i++)
  {
    byte[i] = I2C_readByte();
    I2C_ACK();
  }
  I2C_stop();
}*/

/************************************************************************************************************************/

/*********************************************************Fun��es Timer0*************************************************/
void init_t0(){
    TMR0=0x06; //para contar at� 250;
    OPTION_REG= 0x01;// Set Timer 0 as timer (TOCS=0); Prescale 4;  
}

/************************************************************************************************************************/


/*********************************************************Fun��es valores****************************************************/

void temp_Control(){
    
    if(PORTBbits.RB3 == 0){
        PORTCbits.RC5 =!PORTCbits.RC5;
        delay(20);
    }
  
}

void read_ht(){
    //char tmp;
    //tmp=TRISA;
    //TRISA=0x07;
    t = (ADC_read(TEMP)*10)/2; 
    //TRISA=tmp;
    
    h=((float)ADC_read(HUM)/1023)*100;
}

void temp_Values(){
   
    inttoStr(t, string);
    transmitString("\"Temperatura\":\"");
    transmitChar(string[0]);
    transmitChar(string[1]);
    transmitChar(',');
    transmitChar(string[2]);
    transmitString("\"");
    
}

void hum_Values(){
    
    inttoStr(h, string);
    transmitString("\"Humidade\":\"");
    transmitString(string);
    transmitString("%\"");
}

void wind_Values(){
    
    inttoStr(v, string);
    transmitString("\"Velocidade do Vento\":\"");
    transmitString(string);
    transmitString("\"");
}

/*void P1_Values(){
    int val;
    val=ADC_read(WIND);
    inttoStr(val, string);
    transmitString("P1: ");
    transmitString(string);
    transmitString("\r\n");
}*/

void send_values(){
    transmitString("{");
    temp_Values();
    transmitString(", ");
    hum_Values();
    transmitString(", ");
    wind_Values();
    transmitString("}");
    transmitString("\r\n");
}
/************************************************************************************************************************/


/*********************************************************Fun��es Ventoinha & PWM****************************************************/

/*8.3.3 SETUP FOR PWM OPERATION
The following steps should be taken when configuring
the CCP module for PWM operation:
1. Set the PWM period by writing to the PR2 register.
2. Set the PWM duty cycle by writing to the
CCPR1L register and CCP1CON<5:4> bits.
3. Make the CCP1 pin an output by clearing the
TRISC<2> bit.
4. Set the TMR2 prescale value and enable Timer2
by writing to T2CON.
5. Configure the CCP1 module for PWM operation.*/

void init_fan(){
    CCP1CON = 0x3f; //bit 3-0: 11xx - PWM mode bit 5-4: PWM LSBs;
    PR2 = 0xff; //Set PWM period
    CCPR1L = 0xff; //Set PWM duty cycle
    T2CKPS1=0; //
    T2CKPS0=0; //prescaler=1
    TMR2ON = 1; //ativa Timer 2
    PORTCbits.RC2=1; // ativa a ventoinha
}

void stop_fan(){
    CCP1CON = 0;
    PR2 = 0; //Set PWM period
    CCPR1L = 0; //Set PWM duty cycle
    TMR2ON = 0; //desativa Timer2
    PORTCbits.RC2=0; // desativa a ventoinha
}

void fan_value(){
    int wind = ADC_read(WIND);
    CCPR1L = wind >> 2; //shift 2 p afetar os 2LSB
    delay(50);
}

void read_fan(){
    TMR1 = 0; //TMR1H + TMR1L - Contador
    TMR1ON = 1;
    delay(50); //periodo de contagem
    TMR1ON = 0;
    v=(unsigned)TMR1/2; // /2 para ajustar a gama de valores 0-105
}

/************************************************************************************************************************/

/*********************************************************Interrupts****************************************************/

void init_Interrupt(){
    
    GIE = 1;
    TMR0IE = 1;
    INTCONbits.PEIE = 0;
    INTE = 1;
    RCIE=1;
    
}


void __interrupt() ISR(){
    
    if(INTF == 1){
       
        stop=~stop; 
        if(stop) stop_fan();
        else     init_fan();
        INTF = 0;
        delay(50);
    }
    
    if(T0IF ==1){ //Timer 0 Overflow 
    
        countt0++;

        if(countt0==1000){ //1us*Prescale*timerInterval=1,000e-3 *1000=1s
            sec+=1;
            countt0=0;
            TMR0=0x06;
        }
        if(sec==60){
            minuto=1;
            sec=0;
            //TMR0=0x06
        }
        T0IF=0;
    }
    
}

/************************************************************************************************************************/


int main(void) {
   
   init_Interrupt();
   initUSART();
   //Init_I2C();
   ADC_init();
   init_fan();
   init_t0();
   T1CON=0x02; //inicializa timer1 como contador
   TRISA=0b00000111; //A0, A1, A2 como entrada, os outros como sa�da
   TRISD=0; //define todos os portd como saida
   TRISE=0; // PORTDs como sa�da      
   TRISBbits.TRISB3 = 1; //B3 como entrada
   TRISBbits.TRISB0 = 1; //B0 como entrada
   TRISCbits.TRISC0 = 1; //C0 como entrada
   TRISCbits.TRISC1 = 0; //C1 como sa�da
   TRISCbits.TRISC2 = 0; //C2 como sa�da
   TRISCbits.TRISC5 = 0; //C5 como sa�da
   TRISDbits.TRISD0 = 0; //D0 como sa�da
   PORTDbits.RD0 = 0; //D0 inicicializado a 0
  

   //char tmp=0;
   int i=0;
   int oldvento=0;
   int oldval=0;
   int newval=0;
   int risco=0;
   //int ventoinha;
   limt=40;
   limh=15;
   limv=50; 
   init_fan();
   delay(250);
   
   /*I2C_start();
   I2C_sendByte(0xA0);
   for(i=0;i<10;i++){
        
        I2C_sendByte(i);
        I2C_sendByte(0x02);
   }
   I2C_stop();*/
   do{
        if (stop == 0){
            if(pass==0) password();
           
            else{
                temp_Control();
                fan_value();
                read_ht();
                oldvento=v;
                read_fan();  
                if (minuto==1){ //MSG1
                    send_values();
                    minuto=0;
                }
                //Verificar ocorr�ncia de situa��o de risco
                //t/10 para ajustar
                oldval=newval;
                if((t/10)>=limt || h<=limh || v>=limv ) newval=1;
                else                                    newval=0;
                if(oldval==0 && newval==1){
                    transmitString("{\"Evento\":\"Risco Elevado de Incendio\"}\r\n"); //MSG2               
                    risco=1;
                }     
                if(oldval==1 && newval==0) 
                    risco=0;
                if(risco){//ligar o buzzer e os leds
                    PORTD= 0xFF;
                    PORTCbits.RC1 = 1;
                    for(i = 0 ; i < 20000 ; i++){};
                    PORTD= 0;
                    PORTCbits.RC1 = 0;
                    for(i = 0 ; i < 20000 ; i++){};
                    
                }
                if(RCIF){
                    received=receiveChar();
                    switch(received){
                        case 'v': transmitString("Valores atuais\n");
                                  send_values();
                                  break; 
                        case 'c': received=receiveChar();
                                  limt=(int)received;
                                  received=receiveChar();
                                  limh=(int)received;
                                  received=receiveChar();
                                  limv=(int)received;
                                  transmitString("Calibracao concluida\n");
                                  break;
                        case 'x': transmitString("A Encerrar Programa\n");
                                  break;
                        case '\n': break;
                        default:  transmitString("Opcao invalida\n");       
                    }               
                }            
            }
        }
    }while(1);    
}


